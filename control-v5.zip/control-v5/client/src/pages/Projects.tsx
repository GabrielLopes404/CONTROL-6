import { useState } from "react";
import { useProjects, useClients, useCreateProject, useUpdateProject, useDeleteProject } from "@/hooks/use-api";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Calendar, DollarSign, LayoutGrid, List, MoreVertical, ArrowRight, Sparkles, Target, SlidersHorizontal, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "sonner";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.04 }
  }
};

const item = {
  hidden: { opacity: 0, scale: 0.98 },
  show: { opacity: 1, scale: 1 }
};

export default function Projects() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<any>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    clientId: "",
    status: "proposal",
    deadline: "",
    budget: "",
    progress: 0,
    tags: [] as string[],
  });

  const { data: projects = [], isLoading } = useProjects();
  const { data: clients = [] } = useClients();
  const createMutation = useCreateProject();
  const updateMutation = useUpdateProject();
  const deleteMutation = useDeleteProject();

  const filteredProjects = projects.filter(
    (project: any) =>
      project.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusConfig = (status: string) => {
    switch (status) {
      case "in_progress": return { label: "Andamento", color: "bg-blue-500/15 text-blue-400" };
      case "completed": return { label: "Concluído", color: "bg-emerald-500/15 text-emerald-400" };
      case "proposal": return { label: "Proposta", color: "bg-amber-500/15 text-amber-400" };
      case "review": return { label: "Revisão", color: "bg-purple-500/15 text-purple-400" };
      case "on_hold": return { label: "Pausado", color: "bg-gray-500/15 text-gray-400" };
      default: return { label: status, color: "bg-muted text-muted-foreground" };
    }
  };

  const activeProjects = projects.filter((p: any) => p.status === 'in_progress').length;
  const totalBudget = projects.reduce((acc: number, p: any) => acc + parseFloat(p.budget || 0), 0);

  const resetForm = () => {
    setFormData({ title: "", description: "", clientId: "", status: "proposal", deadline: "", budget: "", progress: 0, tags: [] });
    setEditingProject(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const openEditDialog = (project: any) => {
    setFormData({
      title: project.title,
      description: project.description || "",
      clientId: project.clientId || "",
      status: project.status,
      deadline: project.deadline ? new Date(project.deadline).toISOString().split('T')[0] : "",
      budget: project.budget || "",
      progress: project.progress || 0,
      tags: project.tags || [],
    });
    setEditingProject(project);
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        ...formData,
        deadline: formData.deadline ? new Date(formData.deadline) : null,
        budget: formData.budget || null,
        clientId: formData.clientId || null,
      };
      if (editingProject) {
        await updateMutation.mutateAsync({ id: editingProject.id, data });
        toast.success("Projeto atualizado com sucesso!");
      } else {
        await createMutation.mutateAsync(data);
        toast.success("Projeto criado com sucesso!");
      }
      setIsDialogOpen(false);
      resetForm();
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar projeto");
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este projeto?")) return;
    try {
      await deleteMutation.mutateAsync(id);
      toast.success("Projeto excluído com sucesso!");
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir projeto");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Projetos</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Gerencie suas entregas e cronogramas.</p>
        </div>
        <Button onClick={openCreateDialog} size="sm" className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl">
          <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Novo Projeto
        </Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-primary/10 rounded-lg sm:rounded-xl text-primary">
              <Target className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Total</p>
              <p className="text-lg sm:text-xl font-bold font-heading">{projects.length}</p>
            </div>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-blue-500/10 rounded-lg sm:rounded-xl text-blue-500">
              <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Ativos</p>
              <p className="text-lg sm:text-xl font-bold font-heading">{activeProjects}</p>
            </div>
          </div>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4 col-span-2">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="p-2 sm:p-2.5 bg-emerald-500/10 rounded-lg sm:rounded-xl text-emerald-500">
              <DollarSign className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Orçamento</p>
              <p className="text-lg sm:text-xl font-bold font-heading">R$ {totalBudget.toLocaleString('pt-BR')}</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="flex flex-col gap-2 sm:flex-row sm:items-center p-2 bg-card/40 backdrop-blur-sm rounded-xl sm:rounded-2xl border border-border/40">
        <div className="flex items-center gap-2 flex-1 px-2">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <Input 
            placeholder="Buscar projetos..." 
            className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 h-8 sm:h-9 text-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <div className="bg-muted/30 p-0.5 sm:p-1 rounded-lg sm:rounded-xl flex items-center gap-0.5">
            <Button variant="ghost" size="icon" onClick={() => setViewMode("grid")} className={cn("h-7 w-7 sm:h-8 sm:w-8 rounded-md sm:rounded-lg transition-all", viewMode === "grid" && "bg-background shadow-sm")}>
              <LayoutGrid className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setViewMode("list")} className={cn("h-7 w-7 sm:h-8 sm:w-8 rounded-md sm:rounded-lg transition-all", viewMode === "list" && "bg-background shadow-sm")}>
              <List className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </Button>
          </div>
        </div>
      </div>

      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className={cn(
          "grid gap-3 sm:gap-4",
          viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2 xl:grid-cols-3" : "grid-cols-1"
        )}
      >
        {filteredProjects.map((project: any) => {
          const statusConfig = getStatusConfig(project.status);
          const client = clients.find((c: any) => c.id === project.clientId);
          
          return (
            <motion.div key={project.id} variants={item}>
              <Card className="group border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden hover:border-primary/30 transition-all duration-300 card-hover h-full flex flex-col">
                <CardContent className="p-3 sm:p-5 flex-1">
                  <div className="flex justify-between items-start mb-3 sm:mb-4">
                    <Badge variant="outline" className={cn("text-[9px] sm:text-[10px] font-semibold uppercase tracking-wider border-0 px-1.5 sm:px-2 py-0.5", statusConfig.color)}>
                      {statusConfig.label}
                    </Badge>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-6 w-6 sm:h-8 sm:w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity rounded-md sm:rounded-lg">
                          <MoreVertical className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-muted-foreground" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-xl">
                        <DropdownMenuItem onClick={() => openEditDialog(project)}>Editar</DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(project.id)}>Excluir</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  
                  <h3 className="text-base sm:text-lg font-bold leading-tight group-hover:text-primary transition-colors cursor-pointer mb-1.5 sm:mb-2 line-clamp-2">
                    {project.title}
                  </h3>
                  
                  {client && (
                    <div className="flex items-center gap-2 mb-3 sm:mb-4">
                      <Avatar className="h-5 w-5 sm:h-6 sm:w-6">
                        <AvatarFallback className="text-[9px] sm:text-[10px] bg-muted">{client.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <span className="text-xs sm:text-sm text-muted-foreground truncate">{client.name}</span>
                    </div>
                  )}

                  <div className="space-y-2 sm:space-y-3 mb-3 sm:mb-4">
                    <div className="flex justify-between items-center text-xs sm:text-sm">
                      <span className="text-muted-foreground text-[10px] sm:text-xs">Progresso</span>
                      <span className={cn("font-bold text-[10px] sm:text-xs", project.progress === 100 ? "text-emerald-400" : "text-primary")}>{project.progress || 0}%</span>
                    </div>
                    <Progress value={project.progress || 0} className="h-1.5 sm:h-2" />
                  </div>

                  <div className="flex items-center justify-between text-xs sm:text-sm">
                    {project.deadline && (
                      <div className="flex items-center gap-1 sm:gap-1.5 text-muted-foreground bg-muted/20 px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-md sm:rounded-lg">
                        <Calendar className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                        <span className="text-[10px] sm:text-xs font-medium">{new Date(project.deadline).toLocaleDateString('pt-BR', { day: 'numeric', month: 'short' })}</span>
                      </div>
                    )}
                    {project.budget && (
                      <div className="flex items-center gap-0.5 sm:gap-1 font-mono font-bold">
                        <span className="text-emerald-400 text-[10px] sm:text-xs">R$</span>
                        <span className="text-xs sm:text-sm">{parseFloat(project.budget).toLocaleString('pt-BR')}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
                
                <CardFooter className="bg-muted/10 p-2 sm:p-3 border-t border-border/30">
                  <Button onClick={() => openEditDialog(project)} variant="ghost" className="w-full text-[10px] sm:text-xs font-semibold hover:bg-primary hover:text-white transition-all rounded-lg sm:rounded-xl h-8 sm:h-9 group/btn">
                    Ver Detalhes <ArrowRight className="w-3 h-3 sm:w-3.5 sm:h-3.5 ml-1 sm:ml-1.5 group-hover/btn:translate-x-0.5 transition-transform" />
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          );
        })}
        {filteredProjects.length === 0 && (
          <div className="col-span-full text-center py-12">
            <Target className="w-12 h-12 mx-auto text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground">Nenhum projeto encontrado</p>
            <Button onClick={openCreateDialog} variant="outline" className="mt-4">
              <Plus className="w-4 h-4 mr-2" /> Adicionar Projeto
            </Button>
          </div>
        )}
      </motion.div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingProject ? "Editar Projeto" : "Novo Projeto"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Título *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="client">Cliente</Label>
              <Select value={formData.clientId} onValueChange={(value) => setFormData({ ...formData, clientId: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um cliente" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map((client: any) => (
                    <SelectItem key={client.id} value={client.id}>{client.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="proposal">Proposta</SelectItem>
                    <SelectItem value="in_progress">Em Andamento</SelectItem>
                    <SelectItem value="review">Revisão</SelectItem>
                    <SelectItem value="completed">Concluído</SelectItem>
                    <SelectItem value="on_hold">Pausado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="progress">Progresso (%)</Label>
                <Input
                  id="progress"
                  type="number"
                  min="0"
                  max="100"
                  value={formData.progress}
                  onChange={(e) => setFormData({ ...formData, progress: parseInt(e.target.value) || 0 })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="deadline">Prazo</Label>
                <Input
                  id="deadline"
                  type="date"
                  value={formData.deadline}
                  onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="budget">Orçamento (R$)</Label>
                <Input
                  id="budget"
                  type="number"
                  step="0.01"
                  value={formData.budget}
                  onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {editingProject ? "Salvar" : "Criar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
