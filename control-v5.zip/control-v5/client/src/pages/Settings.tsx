import { useState, useEffect } from "react";
import { useAuthContext } from "@/contexts/AuthContext";
import { useUpdateProfile, useChangePassword, useNotifications, useMarkAllNotificationsRead } from "@/hooks/use-api";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User, Bell, Shield, Palette, Save, Camera, Sparkles, Upload, Globe, Smartphone, Moon, Sun, Monitor, Loader2, Check, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useTheme } from "@/components/theme-provider";
import { toast } from "sonner";
import { motion } from "framer-motion";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.04 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

export default function Settings() {
  const { user, refetch } = useAuthContext();
  const { theme, setTheme } = useTheme();
  const updateProfileMutation = useUpdateProfile();
  const changePasswordMutation = useChangePassword();
  const { data: notifications = [] } = useNotifications();
  const markAllReadMutation = useMarkAllNotificationsRead();

  const [profileForm, setProfileForm] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
  });

  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [notificationSettings, setNotificationSettings] = useState({
    email: true,
    push: true,
    sms: false,
  });

  const [accentColor, setAccentColor] = useState("#FF00AA");
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);

  useEffect(() => {
    if (user) {
      setProfileForm({
        name: user.name || "",
        email: user.email || "",
        phone: (user as any).phone || "",
        company: (user as any).company || "",
      });
      setNotificationSettings({
        email: (user as any).notifyEmail ?? true,
        push: (user as any).notifyPush ?? true,
        sms: (user as any).notifySms ?? false,
      });
      setAccentColor((user as any).accentColor || "#FF00AA");
      setTwoFactorEnabled((user as any).twoFactorEnabled || false);
    }
  }, [user]);

  const handleSaveProfile = async () => {
    try {
      await updateProfileMutation.mutateAsync(profileForm);
      toast.success("Perfil atualizado com sucesso!");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Erro ao atualizar perfil");
    }
  };

  const handleChangePassword = async () => {
    if (!passwordForm.currentPassword) {
      toast.error("Digite sua senha atual");
      return;
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error("As senhas não coincidem");
      return;
    }
    if (passwordForm.newPassword.length < 6) {
      toast.error("A senha deve ter pelo menos 6 caracteres");
      return;
    }
    try {
      await changePasswordMutation.mutateAsync({ 
        currentPassword: passwordForm.currentPassword, 
        newPassword: passwordForm.newPassword 
      });
      toast.success("Senha alterada com sucesso!");
      setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
    } catch (error: any) {
      toast.error(error.message || "Erro ao alterar senha");
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await markAllReadMutation.mutateAsync();
      toast.success("Notificações marcadas como lidas");
    } catch (error: any) {
      toast.error(error.message || "Erro ao marcar notificações");
    }
  };

  const handleSaveNotificationSettings = async () => {
    try {
      await updateProfileMutation.mutateAsync({
        notifyEmail: notificationSettings.email,
        notifyPush: notificationSettings.push,
        notifySms: notificationSettings.sms,
      });
      toast.success("Preferências de notificação salvas!");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar preferências");
    }
  };

  const handleChangeAccentColor = async (color: string) => {
    setAccentColor(color);
    try {
      await updateProfileMutation.mutateAsync({ accentColor: color });
      document.documentElement.style.setProperty('--primary', color);
      toast.success("Cor de destaque alterada!");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Erro ao alterar cor");
    }
  };

  const handleToggle2FA = async () => {
    const newValue = !twoFactorEnabled;
    setTwoFactorEnabled(newValue);
    try {
      await updateProfileMutation.mutateAsync({ twoFactorEnabled: newValue });
      toast.success(newValue ? "2FA ativado!" : "2FA desativado");
      refetch();
    } catch (error: any) {
      setTwoFactorEnabled(!newValue);
      toast.error(error.message || "Erro ao alterar 2FA");
    }
  };

  const unreadCount = notifications.filter((n: any) => !n.read).length;
  const initials = user?.name?.split(' ').map((n: string) => n[0]).join('').toUpperCase() || 'U';

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-4 sm:space-y-6"
    >
      <motion.div variants={item} className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Configurações</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Gerencie suas preferências e perfil.</p>
        </div>
      </motion.div>

      <Tabs defaultValue="profile" className="w-full">
        <div className="flex flex-col lg:flex-row gap-4 sm:gap-6">
          <motion.aside variants={item} className="w-full lg:w-56 shrink-0">
            <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
              <CardContent className="p-1.5 sm:p-2">
                <TabsList className="flex lg:flex-col h-auto bg-transparent p-0 gap-0.5 sm:gap-1 w-full">
                  <TabsTrigger value="profile" className="flex-1 lg:w-full justify-center lg:justify-start px-2 sm:px-3 py-2 sm:py-2.5 rounded-lg sm:rounded-xl data-[state=active]:bg-primary/10 data-[state=active]:text-primary text-[10px] sm:text-sm font-medium">
                    <User className="w-3.5 h-3.5 sm:w-4 sm:h-4 lg:mr-2.5" /> <span className="hidden lg:inline">Perfil</span>
                  </TabsTrigger>
                  <TabsTrigger value="appearance" className="flex-1 lg:w-full justify-center lg:justify-start px-2 sm:px-3 py-2 sm:py-2.5 rounded-lg sm:rounded-xl data-[state=active]:bg-primary/10 data-[state=active]:text-primary text-[10px] sm:text-sm font-medium">
                    <Palette className="w-3.5 h-3.5 sm:w-4 sm:h-4 lg:mr-2.5" /> <span className="hidden lg:inline">Aparência</span>
                  </TabsTrigger>
                  <TabsTrigger value="notifications" className="flex-1 lg:w-full justify-center lg:justify-start px-2 sm:px-3 py-2 sm:py-2.5 rounded-lg sm:rounded-xl data-[state=active]:bg-primary/10 data-[state=active]:text-primary text-[10px] sm:text-sm font-medium relative">
                    <Bell className="w-3.5 h-3.5 sm:w-4 sm:h-4 lg:mr-2.5" /> <span className="hidden lg:inline">Notificações</span>
                    {unreadCount > 0 && (
                      <Badge className="absolute -top-1 -right-1 lg:static lg:ml-auto h-4 w-4 lg:h-5 lg:w-5 p-0 flex items-center justify-center bg-primary text-[9px]">
                        {unreadCount}
                      </Badge>
                    )}
                  </TabsTrigger>
                  <TabsTrigger value="security" className="flex-1 lg:w-full justify-center lg:justify-start px-2 sm:px-3 py-2 sm:py-2.5 rounded-lg sm:rounded-xl data-[state=active]:bg-primary/10 data-[state=active]:text-primary text-[10px] sm:text-sm font-medium">
                    <Shield className="w-3.5 h-3.5 sm:w-4 sm:h-4 lg:mr-2.5" /> <span className="hidden lg:inline">Segurança</span>
                  </TabsTrigger>
                </TabsList>
              </CardContent>
            </Card>
          </motion.aside>

          <motion.div variants={item} className="flex-1">
            <TabsContent value="profile" className="m-0 space-y-4 sm:space-y-6">
              <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
                <CardHeader className="pb-3 sm:pb-4 px-4 sm:px-6 pt-4 sm:pt-6">
                  <CardTitle className="text-base sm:text-lg font-heading">Informações Pessoais</CardTitle>
                  <CardDescription className="text-[10px] sm:text-sm">Atualize sua foto e dados de contato.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 sm:space-y-6 px-4 sm:px-6 pb-4 sm:pb-6">
                  <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 pb-4 sm:pb-6 border-b border-border/40">
                    <div className="relative group">
                      <Avatar className="h-20 w-20 sm:h-24 sm:w-24 border-4 border-card shadow-lg">
                        <AvatarImage src={user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.username}`} />
                        <AvatarFallback className="text-xl sm:text-2xl bg-gradient-to-br from-primary/20 to-purple-500/20 font-heading font-bold">{initials}</AvatarFallback>
                      </Avatar>
                      <Button size="icon" className="absolute bottom-0 right-0 h-7 w-7 sm:h-8 sm:w-8 rounded-full bg-primary hover:bg-primary/90 shadow-lg border-2 border-card">
                        <Camera className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                      </Button>
                    </div>
                    <div className="text-center sm:text-left">
                      <h3 className="font-bold text-base sm:text-lg font-heading">{user?.name || 'Usuário'}</h3>
                      <p className="text-[10px] sm:text-sm text-muted-foreground">{user?.email}</p>
                      <p className="text-[10px] sm:text-xs text-primary mt-1">@{user?.username}</p>
                    </div>
                  </div>

                  <div className="grid gap-4 sm:gap-6 sm:grid-cols-2">
                    <div className="space-y-1.5 sm:space-y-2">
                      <Label className="text-[10px] sm:text-xs font-semibold text-muted-foreground uppercase tracking-wider">Nome Completo</Label>
                      <Input 
                        value={profileForm.name}
                        onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                        className="h-9 sm:h-10 bg-muted/30 border-border/40 rounded-lg sm:rounded-xl text-xs sm:text-sm" 
                      />
                    </div>
                    <div className="space-y-1.5 sm:space-y-2">
                      <Label className="text-[10px] sm:text-xs font-semibold text-muted-foreground uppercase tracking-wider">Email</Label>
                      <Input 
                        type="email"
                        value={profileForm.email}
                        onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                        className="h-9 sm:h-10 bg-muted/30 border-border/40 rounded-lg sm:rounded-xl text-xs sm:text-sm" 
                      />
                    </div>
                    <div className="space-y-1.5 sm:space-y-2">
                      <Label className="text-[10px] sm:text-xs font-semibold text-muted-foreground uppercase tracking-wider">Telefone</Label>
                      <Input 
                        value={profileForm.phone}
                        onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                        placeholder="+55 (11) 99999-9999"
                        className="h-9 sm:h-10 bg-muted/30 border-border/40 rounded-lg sm:rounded-xl text-xs sm:text-sm" 
                      />
                    </div>
                    <div className="space-y-1.5 sm:space-y-2">
                      <Label className="text-[10px] sm:text-xs font-semibold text-muted-foreground uppercase tracking-wider">Empresa</Label>
                      <Input 
                        value={profileForm.company}
                        onChange={(e) => setProfileForm({ ...profileForm, company: e.target.value })}
                        placeholder="Sua empresa"
                        className="h-9 sm:h-10 bg-muted/30 border-border/40 rounded-lg sm:rounded-xl text-xs sm:text-sm" 
                      />
                    </div>
                  </div>

                  <Button 
                    onClick={handleSaveProfile}
                    disabled={updateProfileMutation.isPending}
                    className="w-full sm:w-auto h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl"
                  >
                    {updateProfileMutation.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Save className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" />
                    )}
                    Salvar Alterações
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="appearance" className="m-0 space-y-4 sm:space-y-6">
              <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
                <CardHeader className="pb-3 sm:pb-4 px-4 sm:px-6 pt-4 sm:pt-6">
                  <CardTitle className="text-base sm:text-lg font-heading">Tema</CardTitle>
                  <CardDescription className="text-[10px] sm:text-sm">Escolha o visual do sistema.</CardDescription>
                </CardHeader>
                <CardContent className="px-4 sm:px-6 pb-4 sm:pb-6">
                  <div className="grid grid-cols-3 gap-2 sm:gap-4">
                    {[
                      { name: "Escuro", value: "dark", bg: "bg-zinc-900", icon: Moon },
                      { name: "Claro", value: "light", bg: "bg-white", icon: Sun },
                      { name: "Sistema", value: "system", bg: "bg-gradient-to-br from-white to-zinc-900", icon: Monitor },
                    ].map((t) => (
                      <button 
                        key={t.value}
                        onClick={() => setTheme(t.value as "dark" | "light" | "system")}
                        className={cn(
                          "aspect-video rounded-lg sm:rounded-xl border-2 transition-all overflow-hidden relative group",
                          theme === t.value ? "border-primary ring-2 ring-primary/30" : "border-border/40 hover:border-border/60"
                        )}
                      >
                        <div className={cn("absolute inset-0", t.bg)} />
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20">
                          <t.icon className="w-5 h-5 text-white" />
                        </div>
                        <span className={cn(
                          "absolute bottom-1 sm:bottom-2 left-1/2 -translate-x-1/2 text-[9px] sm:text-[10px] font-semibold px-1.5 sm:px-2 py-0.5 rounded-md bg-card/80 backdrop-blur-sm flex items-center gap-1",
                          theme === t.value && "text-primary"
                        )}>
                          {theme === t.value && <Check className="w-3 h-3" />}
                          {t.name}
                        </span>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
                <CardHeader className="pb-3 sm:pb-4 px-4 sm:px-6 pt-4 sm:pt-6">
                  <CardTitle className="text-base sm:text-lg font-heading">Cor de Destaque</CardTitle>
                  <CardDescription className="text-[10px] sm:text-sm">Escolha sua cor favorita.</CardDescription>
                </CardHeader>
                <CardContent className="px-4 sm:px-6 pb-4 sm:pb-6">
                  <div className="flex flex-wrap gap-2 sm:gap-3">
                    {[
                      { hex: "#FF00AA", name: "Rosa" },
                      { hex: "#3B82F6", name: "Azul" },
                      { hex: "#10B981", name: "Verde" },
                      { hex: "#8B5CF6", name: "Roxo" },
                      { hex: "#F59E0B", name: "Âmbar" },
                      { hex: "#EF4444", name: "Vermelho" },
                    ].map((c) => (
                      <button
                        key={c.name}
                        onClick={() => handleChangeAccentColor(c.hex)}
                        className={cn(
                          "w-10 h-10 sm:w-12 sm:h-12 rounded-xl transition-all hover:scale-105",
                          accentColor === c.hex && "ring-2 ring-offset-2 ring-offset-background ring-white"
                        )}
                        style={{ backgroundColor: c.hex }}
                        title={c.name}
                      />
                    ))}
                  </div>
                  <p className="text-[10px] sm:text-xs text-muted-foreground mt-3">
                    Cor atual: {accentColor}
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notifications" className="m-0 space-y-4 sm:space-y-6">
              <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
                <CardHeader className="pb-3 sm:pb-4 px-4 sm:px-6 pt-4 sm:pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base sm:text-lg font-heading">Preferências de Notificação</CardTitle>
                      <CardDescription className="text-[10px] sm:text-sm">Escolha como deseja ser notificado.</CardDescription>
                    </div>
                    {unreadCount > 0 && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={handleMarkAllRead}
                        disabled={markAllReadMutation.isPending}
                        className="text-xs"
                      >
                        <Check className="w-3 h-3 mr-1" /> Marcar todas como lidas
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="px-4 sm:px-6 pb-4 sm:pb-6 space-y-3 sm:space-y-4">
                  {[
                    { key: "email", title: "Email", desc: "Receba atualizações por email", icon: Globe },
                    { key: "push", title: "Push", desc: "Notificações no navegador", icon: Bell },
                    { key: "sms", title: "SMS", desc: "Alertas importantes via SMS", icon: Smartphone },
                  ].map((it) => (
                    <div key={it.key} className="flex items-center justify-between p-3 sm:p-4 bg-muted/10 rounded-lg sm:rounded-xl border border-border/40">
                      <div className="flex items-center gap-3 sm:gap-4">
                        <div className="p-2 sm:p-2.5 bg-primary/10 rounded-lg text-primary">
                          <it.icon className="w-4 h-4 sm:w-5 sm:h-5" />
                        </div>
                        <div>
                          <p className="font-semibold text-xs sm:text-sm">{it.title}</p>
                          <p className="text-[9px] sm:text-xs text-muted-foreground">{it.desc}</p>
                        </div>
                      </div>
                      <Switch 
                        checked={notificationSettings[it.key as keyof typeof notificationSettings]}
                        onCheckedChange={(checked) => setNotificationSettings({ ...notificationSettings, [it.key]: checked })}
                      />
                    </div>
                  ))}
                  <Button 
                    onClick={handleSaveNotificationSettings}
                    disabled={updateProfileMutation.isPending}
                    className="w-full sm:w-auto h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl mt-4"
                  >
                    {updateProfileMutation.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Save className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" />
                    )}
                    Salvar Preferências
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
                <CardHeader className="pb-3 sm:pb-4 px-4 sm:px-6 pt-4 sm:pt-6">
                  <CardTitle className="text-base sm:text-lg font-heading">Histórico de Notificações</CardTitle>
                  <CardDescription className="text-[10px] sm:text-sm">Suas últimas notificações.</CardDescription>
                </CardHeader>
                <CardContent className="px-4 sm:px-6 pb-4 sm:pb-6">
                  {notifications.length > 0 ? (
                    <div className="space-y-2">
                      {notifications.slice(0, 5).map((notif: any) => (
                        <div 
                          key={notif.id} 
                          className={cn(
                            "p-3 rounded-lg border transition-colors",
                            notif.read ? "bg-muted/5 border-border/20" : "bg-primary/5 border-primary/20"
                          )}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="text-sm font-medium">{notif.title}</p>
                              <p className="text-xs text-muted-foreground">{notif.message}</p>
                            </div>
                            {!notif.read && (
                              <div className="w-2 h-2 bg-primary rounded-full mt-1" />
                            )}
                          </div>
                          <p className="text-[10px] text-muted-foreground mt-1">
                            {new Date(notif.createdAt).toLocaleDateString('pt-BR')}
                          </p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center text-muted-foreground py-8 text-sm">Nenhuma notificação</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="security" className="m-0 space-y-4 sm:space-y-6">
              <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
                <CardHeader className="pb-3 sm:pb-4 px-4 sm:px-6 pt-4 sm:pt-6">
                  <CardTitle className="text-base sm:text-lg font-heading">Alterar Senha</CardTitle>
                  <CardDescription className="text-[10px] sm:text-sm">Mantenha sua conta segura.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 sm:space-y-6 px-4 sm:px-6 pb-4 sm:pb-6">
                  <div className="space-y-1.5 sm:space-y-2">
                    <Label className="text-[10px] sm:text-xs font-semibold text-muted-foreground uppercase tracking-wider">Senha Atual</Label>
                    <Input 
                      type="password" 
                      value={passwordForm.currentPassword}
                      onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                      placeholder="••••••••" 
                      className="h-9 sm:h-10 bg-muted/30 border-border/40 rounded-lg sm:rounded-xl text-sm" 
                    />
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-1.5 sm:space-y-2">
                      <Label className="text-[10px] sm:text-xs font-semibold text-muted-foreground uppercase tracking-wider">Nova Senha</Label>
                      <Input 
                        type="password" 
                        value={passwordForm.newPassword}
                        onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                        placeholder="••••••••" 
                        className="h-9 sm:h-10 bg-muted/30 border-border/40 rounded-lg sm:rounded-xl text-sm" 
                      />
                    </div>
                    <div className="space-y-1.5 sm:space-y-2">
                      <Label className="text-[10px] sm:text-xs font-semibold text-muted-foreground uppercase tracking-wider">Confirmar Senha</Label>
                      <Input 
                        type="password" 
                        value={passwordForm.confirmPassword}
                        onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                        placeholder="••••••••" 
                        className="h-9 sm:h-10 bg-muted/30 border-border/40 rounded-lg sm:rounded-xl text-sm" 
                      />
                    </div>
                  </div>

                  <Button 
                    onClick={handleChangePassword}
                    disabled={changePasswordMutation.isPending || !passwordForm.newPassword || !passwordForm.currentPassword}
                    className="w-full sm:w-auto h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl"
                  >
                    {changePasswordMutation.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Shield className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" />
                    )}
                    Alterar Senha
                  </Button>

                  <div className="p-3 sm:p-4 bg-muted/10 rounded-lg sm:rounded-xl border border-border/40">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3 sm:gap-4">
                        <div className={cn(
                          "p-2 sm:p-2.5 rounded-lg",
                          twoFactorEnabled ? "bg-emerald-500/10 text-emerald-500" : "bg-muted/20 text-muted-foreground"
                        )}>
                          <Shield className="w-4 h-4 sm:w-5 sm:h-5" />
                        </div>
                        <div>
                          <p className="font-semibold text-xs sm:text-sm">Autenticação 2FA</p>
                          <p className="text-[9px] sm:text-xs text-muted-foreground">
                            {twoFactorEnabled ? "Ativado - sua conta está protegida" : "Proteção extra para sua conta"}
                          </p>
                        </div>
                      </div>
                      <Switch 
                        checked={twoFactorEnabled}
                        onCheckedChange={handleToggle2FA}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl border-red-500/20">
                <CardHeader className="pb-3 sm:pb-4 px-4 sm:px-6 pt-4 sm:pt-6">
                  <CardTitle className="text-base sm:text-lg font-heading text-red-500">Zona de Perigo</CardTitle>
                  <CardDescription className="text-[10px] sm:text-sm">Ações irreversíveis.</CardDescription>
                </CardHeader>
                <CardContent className="px-4 sm:px-6 pb-4 sm:pb-6">
                  <div className="p-3 sm:p-4 bg-red-500/5 rounded-lg sm:rounded-xl border border-red-500/20">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-xs sm:text-sm text-red-400">Excluir Conta</p>
                        <p className="text-[9px] sm:text-xs text-muted-foreground">Esta ação não pode ser desfeita</p>
                      </div>
                      <Button variant="destructive" size="sm" className="text-xs">
                        <Trash2 className="w-3 h-3 mr-1" /> Excluir
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </motion.div>
        </div>
      </Tabs>
    </motion.div>
  );
}
