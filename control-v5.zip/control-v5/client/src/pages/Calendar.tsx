import { useState } from "react";
import { useCalendarEvents, useTasks, useCreateCalendarEvent } from "@/hooks/use-api";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Plus, Sparkles, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { motion } from "framer-motion";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.04 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

const days = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

export default function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    startDate: "",
    endDate: "",
    type: "event",
  });

  const { data: events = [], isLoading: loadingEvents } = useCalendarEvents();
  const { data: tasks = [], isLoading: loadingTasks } = useTasks();
  const createEventMutation = useCreateCalendarEvent();

  const isLoading = loadingEvents || loadingTasks;

  const currentMonth = currentDate.toLocaleString('pt-BR', { month: 'long' });
  const currentYear = currentDate.getFullYear();

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    const days = [];
    
    const prevMonthLastDay = new Date(year, month, 0).getDate();
    for (let i = startingDay - 1; i >= 0; i--) {
      days.push({ day: prevMonthLastDay - i, type: "prev", date: new Date(year, month - 1, prevMonthLastDay - i) });
    }
    
    for (let i = 1; i <= daysInMonth; i++) {
      days.push({ day: i, type: "current", date: new Date(year, month, i) });
    }
    
    const remainingDays = 42 - days.length;
    for (let i = 1; i <= remainingDays; i++) {
      days.push({ day: i, type: "next", date: new Date(year, month + 1, i) });
    }
    
    return days;
  };

  const calendarDays = getDaysInMonth(currentDate);
  const today = new Date();

  const getEventsForDay = (date: Date) => {
    const dayEvents = events.filter((e: any) => {
      const eventDate = new Date(e.startDate);
      return eventDate.toDateString() === date.toDateString();
    });
    
    const dayTasks = tasks.filter((t: any) => {
      if (!t.dueDate) return false;
      const taskDate = new Date(t.dueDate);
      return taskDate.toDateString() === date.toDateString();
    });
    
    return [...dayEvents.map((e: any) => ({ ...e, isEvent: true })), ...dayTasks.map((t: any) => ({ ...t, isTask: true }))];
  };

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createEventMutation.mutateAsync({
        ...formData,
        startDate: new Date(formData.startDate),
        endDate: formData.endDate ? new Date(formData.endDate) : null,
      });
      toast.success("Evento criado com sucesso!");
      setIsDialogOpen(false);
      setFormData({ title: "", description: "", startDate: "", endDate: "", type: "event" });
    } catch (error: any) {
      toast.error(error.message || "Erro ao criar evento");
    }
  };

  const upcomingEvents = [...events, ...tasks.filter((t: any) => t.dueDate)]
    .map((item: any) => ({
      ...item,
      date: new Date(item.startDate || item.dueDate),
      isTask: !!item.dueDate && !item.startDate
    }))
    .filter((item: any) => item.date >= today)
    .sort((a: any, b: any) => a.date - b.date)
    .slice(0, 5);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-4 sm:space-y-6"
    >
      <motion.div variants={item} className="flex flex-col gap-3 sm:gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-0.5 sm:space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-bold tracking-tight">Calendário</h1>
            <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
          </div>
          <p className="text-muted-foreground text-xs sm:text-sm lg:text-base">Visualize seus prazos e entregas.</p>
        </div>
        <Button 
          onClick={() => setIsDialogOpen(true)}
          className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl"
        >
          <Plus className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Novo Evento
        </Button>
      </motion.div>

      <motion.div variants={item}>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between py-3 sm:py-4 px-3 sm:px-4 lg:px-6 border-b border-border/40 bg-muted/10">
            <div className="flex items-center gap-2 sm:gap-3 lg:gap-4">
              <h2 className="text-lg sm:text-xl lg:text-2xl font-bold font-heading capitalize">{currentMonth} {currentYear}</h2>
              <div className="flex items-center bg-muted/30 rounded-md sm:rounded-lg p-0.5">
                <Button variant="ghost" size="icon" className="h-6 w-6 sm:h-8 sm:w-8 rounded-md hover:bg-muted/50" onClick={handlePrevMonth}>
                  <ChevronLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-6 w-6 sm:h-8 sm:w-8 rounded-md hover:bg-muted/50" onClick={handleNextMonth}>
                  <ChevronRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </Button>
              </div>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setCurrentDate(new Date())}
              className="text-xs h-8"
            >
              Hoje
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <div className="grid grid-cols-7 border-b border-border/40">
              {days.map(day => (
                <div key={day} className="py-2 sm:py-2.5 text-center text-[10px] sm:text-xs font-semibold text-muted-foreground uppercase tracking-wider border-r border-border/30 last:border-r-0">
                  <span className="hidden sm:inline">{day}</span>
                  <span className="sm:hidden">{day.charAt(0)}</span>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 auto-rows-fr">
              {calendarDays.map((date, index) => {
                const dayEvents = getEventsForDay(date.date);
                const isToday = date.day === today.getDate() && 
                               date.date.getMonth() === today.getMonth() && 
                               date.date.getFullYear() === today.getFullYear() &&
                               date.type === "current";
                
                return (
                  <div 
                    key={`${date.type}-${date.day}-${index}`}
                    className={cn(
                      "min-h-[60px] sm:min-h-[80px] lg:min-h-[100px] border-r border-b border-border/30 p-1 sm:p-1.5 lg:p-2 hover:bg-muted/10 transition-colors relative group",
                      date.type !== "current" && "bg-muted/5 text-muted-foreground/40",
                      index % 7 === 6 && "border-r-0"
                    )}
                  >
                    <div className="flex items-center justify-between mb-0.5 sm:mb-1">
                      <span className={cn(
                        "text-[10px] sm:text-xs lg:text-sm font-medium w-5 h-5 sm:w-6 sm:h-6 flex items-center justify-center rounded-full transition-colors",
                        isToday ? "bg-primary text-primary-foreground font-bold" : ""
                      )}>
                        {date.day}
                      </span>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-4 w-4 sm:h-5 sm:w-5 opacity-0 group-hover:opacity-100 transition-opacity rounded-md hidden sm:flex"
                        onClick={() => {
                          setFormData({ ...formData, startDate: date.date.toISOString().split('T')[0] });
                          setIsDialogOpen(true);
                        }}
                      >
                        <Plus className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                      </Button>
                    </div>
                    
                    <div className="space-y-0.5 hidden sm:block">
                      {dayEvents.slice(0, 2).map((event: any, i: number) => (
                        <div 
                          key={`event-${event.id}-${i}`}
                          className={cn(
                            "text-[9px] sm:text-[10px] px-1 sm:px-1.5 py-0.5 rounded truncate cursor-pointer border-l-2 hover:opacity-80 transition-opacity",
                            event.isTask 
                              ? event.priority === "high" ? "bg-red-500/10 border-red-500 text-red-400" :
                                event.priority === "medium" ? "bg-amber-500/10 border-amber-500 text-amber-400" :
                                "bg-blue-500/10 border-blue-500 text-blue-400"
                              : "bg-primary/10 border-primary text-primary"
                          )}
                        >
                          {event.title}
                        </div>
                      ))}
                      {dayEvents.length > 2 && (
                        <div className="text-[9px] sm:text-[10px] text-muted-foreground px-1 sm:px-1.5">
                          +{dayEvents.length - 2}
                        </div>
                      )}
                    </div>
                    
                    <div className="sm:hidden">
                      {dayEvents.length > 0 && (
                        <div className="flex gap-0.5 mt-0.5">
                          {dayEvents.slice(0, 3).map((event: any, i: number) => (
                            <div 
                              key={`dot-${event.id}-${i}`}
                              className={cn(
                                "w-1.5 h-1.5 rounded-full",
                                event.isTask 
                                  ? event.priority === "high" ? "bg-red-500" :
                                    event.priority === "medium" ? "bg-amber-500" : "bg-blue-500"
                                  : "bg-primary"
                              )}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={item} className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4">
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
          <CardHeader className="pb-2 sm:pb-3 px-3 sm:px-4 pt-3 sm:pt-4">
            <h3 className="font-heading font-bold text-xs sm:text-sm uppercase tracking-wider">Próximos Eventos</h3>
          </CardHeader>
          <CardContent className="space-y-2 sm:space-y-3 px-3 sm:px-4 pb-3 sm:pb-4">
            {upcomingEvents.length > 0 ? upcomingEvents.map((event: any) => (
              <div key={`upcoming-${event.id}`} className="flex items-center gap-2 sm:gap-3 p-2 sm:p-2.5 rounded-lg sm:rounded-xl bg-muted/20 hover:bg-muted/30 transition-colors cursor-pointer">
                <div className={cn(
                  "w-0.5 sm:w-1 h-6 sm:h-8 rounded-full",
                  event.isTask ? "bg-amber-500" : "bg-primary"
                )} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs sm:text-sm font-medium truncate">{event.title}</p>
                  <p className="text-[10px] sm:text-xs text-muted-foreground">
                    {event.date.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}
                  </p>
                </div>
                <Badge variant="outline" className={cn(
                  "text-[8px] sm:text-[9px] border-0 shrink-0",
                  event.isTask ? "bg-amber-500/15 text-amber-400" : "bg-primary/15 text-primary"
                )}>
                  {event.isTask ? "Tarefa" : "Evento"}
                </Badge>
              </div>
            )) : (
              <p className="text-center text-muted-foreground text-sm py-4">Nenhum evento próximo</p>
            )}
          </CardContent>
        </Card>

        <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl lg:col-span-2">
          <CardHeader className="pb-2 sm:pb-3 px-3 sm:px-4 pt-3 sm:pt-4">
            <h3 className="font-heading font-bold text-xs sm:text-sm uppercase tracking-wider">Esta Semana</h3>
          </CardHeader>
          <CardContent className="px-3 sm:px-4 pb-3 sm:pb-4">
            <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
              {["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"].map((day, i) => {
                const dayDate = new Date(today);
                const dayOfWeek = today.getDay();
                const diff = i - (dayOfWeek === 0 ? 6 : dayOfWeek - 1);
                dayDate.setDate(today.getDate() + diff);
                const isToday = dayDate.toDateString() === today.toDateString();
                const dayEvents = getEventsForDay(dayDate);

                return (
                  <div key={`week-${day}`} className="text-center">
                    <p className="text-[9px] sm:text-[10px] text-muted-foreground uppercase mb-1.5 sm:mb-2">
                      <span className="hidden sm:inline">{day}</span>
                      <span className="sm:hidden">{day.charAt(0)}</span>
                    </p>
                    <div className={cn(
                      "aspect-square rounded-lg sm:rounded-xl flex items-center justify-center text-xs sm:text-sm font-bold transition-colors cursor-pointer",
                      isToday ? "bg-primary text-white" : "bg-muted/30 hover:bg-muted/50"
                    )}>
                      {dayDate.getDate()}
                    </div>
                    <div className="mt-1 sm:mt-1.5 space-y-0.5">
                      {dayEvents.length > 0 && (
                        <div className="w-full h-0.5 sm:h-1 rounded-full bg-primary/50" />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Novo Evento</DialogTitle>
            <DialogDescription>Adicione um novo evento ao seu calendário.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreateEvent} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Título *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate">Data Início *</Label>
                <Input
                  id="startDate"
                  type="datetime-local"
                  value={formData.startDate}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="endDate">Data Fim</Label>
                <Input
                  id="endDate"
                  type="datetime-local"
                  value={formData.endDate}
                  onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={createEventMutation.isPending}>
                {createEventMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Criar Evento
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
