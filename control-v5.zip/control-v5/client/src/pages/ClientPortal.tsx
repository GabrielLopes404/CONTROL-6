import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, CheckCircle2, Clock, FileText, MessageSquare, Sparkles, CreditCard, ArrowRight, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.06 }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

async function fetchProposalByToken(token: string) {
  const res = await fetch(`/api/proposals/share/${token}`);
  if (!res.ok) throw new Error("Proposta não encontrada");
  return res.json();
}

export default function ClientPortal() {
  const { token } = useParams<{ token: string }>();
  
  const { data: proposal, isLoading, error } = useQuery({
    queryKey: ["proposal-share", token],
    queryFn: () => fetchProposalByToken(token || ""),
    enabled: !!token,
  });

  if (!token) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <FileText className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h2 className="text-xl font-bold mb-2">Portal do Cliente</h2>
            <p className="text-muted-foreground">Token de acesso inválido ou não fornecido.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Carregando proposta...</p>
        </div>
      </div>
    );
  }

  if (error || !proposal) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-8 text-center">
            <FileText className="w-12 h-12 mx-auto mb-4 text-destructive" />
            <h2 className="text-xl font-bold mb-2">Proposta não encontrada</h2>
            <p className="text-muted-foreground">O link pode ter expirado ou a proposta foi removida.</p>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  const proposalValue = parseFloat(proposal.value) || 0;
  
  return (
    <div className="min-h-screen bg-background font-sans">
      <header className="h-14 sm:h-16 lg:h-20 border-b border-border/40 bg-card/60 backdrop-blur-xl flex items-center justify-between px-4 sm:px-6 lg:px-12 sticky top-0 z-20">
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-primary to-purple-600 rounded-lg sm:rounded-xl flex items-center justify-center font-heading font-bold text-lg sm:text-2xl text-primary-foreground shadow-lg shadow-primary/30">
            L
          </div>
          <div className="h-6 sm:h-8 w-px bg-border mx-1 sm:mx-2 hidden sm:block" />
          <h2 className="text-sm sm:text-lg font-bold font-heading hidden sm:block">Proposta Comercial</h2>
        </div>
        <Badge className={cn(
          "text-xs uppercase tracking-wider",
          proposal.status === "accepted" && "bg-emerald-500/20 text-emerald-400",
          proposal.status === "sent" && "bg-blue-500/20 text-blue-400",
          proposal.status === "rejected" && "bg-red-500/20 text-red-400",
          proposal.status === "draft" && "bg-yellow-500/20 text-yellow-400",
        )}>
          {proposal.status === "accepted" ? "Aceita" : 
           proposal.status === "sent" ? "Enviada" : 
           proposal.status === "rejected" ? "Recusada" : "Rascunho"}
        </Badge>
      </header>

      <motion.main 
        variants={container}
        initial="hidden"
        animate="show"
        className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-12 space-y-4 sm:space-y-6 lg:space-y-8"
      >
        <motion.div variants={item} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-heading font-bold">{proposal.title}</h1>
              <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-primary" />
            </div>
            <p className="text-muted-foreground text-[10px] sm:text-sm">Proposta comercial personalizada</p>
          </div>
          <Button className="h-9 sm:h-10 text-xs sm:text-sm bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white shadow-lg shadow-primary/25 border-0 rounded-xl">
            <MessageSquare className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> Enviar Mensagem
          </Button>
        </motion.div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-3 lg:gap-4">
          <motion.div variants={item}>
            <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="p-2 sm:p-2.5 bg-primary/10 rounded-lg sm:rounded-xl text-primary">
                  <CreditCard className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div>
                  <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Valor</p>
                  <p className="text-lg sm:text-xl font-bold font-heading">R$ {proposalValue.toLocaleString('pt-BR')}</p>
                </div>
              </div>
            </Card>
          </motion.div>
          <motion.div variants={item}>
            <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="p-2 sm:p-2.5 bg-blue-500/10 rounded-lg sm:rounded-xl text-blue-500">
                  <Clock className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div>
                  <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Válida até</p>
                  <p className="text-lg sm:text-xl font-bold font-heading">
                    {proposal.validUntil ? new Date(proposal.validUntil).toLocaleDateString('pt-BR') : "Sem prazo"}
                  </p>
                </div>
              </div>
            </Card>
          </motion.div>
          <motion.div variants={item} className="col-span-2 lg:col-span-1">
            <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4">
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="p-2 sm:p-2.5 bg-emerald-500/10 rounded-lg sm:rounded-xl text-emerald-500">
                  <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div>
                  <p className="text-[9px] sm:text-[11px] text-muted-foreground uppercase tracking-wider font-medium">Visualizações</p>
                  <p className="text-lg sm:text-xl font-bold font-heading">{proposal.viewCount || 0}</p>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>

        <motion.div variants={item}>
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
            <CardHeader className="pb-2 sm:pb-3 px-4 sm:px-6 pt-4 sm:pt-6">
              <CardTitle className="text-sm sm:text-base lg:text-lg font-heading">Detalhes da Proposta</CardTitle>
            </CardHeader>
            <CardContent className="px-4 sm:px-6 pb-4 sm:pb-6">
              <div className="prose prose-sm dark:prose-invert max-w-none">
                <p className="text-muted-foreground whitespace-pre-wrap">
                  {proposal.description || "Sem descrição adicional."}
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {proposal.status === "sent" && (
          <motion.div variants={item} className="flex gap-3 justify-center">
            <Button 
              size="lg"
              className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:opacity-90 text-white rounded-xl"
            >
              <CheckCircle2 className="w-4 h-4 mr-2" /> Aceitar Proposta
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="rounded-xl"
            >
              Solicitar Alterações
            </Button>
          </motion.div>
        )}

        <motion.div variants={item}>
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm rounded-xl sm:rounded-2xl">
            <CardContent className="p-4 sm:p-6 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Baixar proposta em PDF</p>
                <p className="text-xs text-muted-foreground">Versão completa para impressão</p>
              </div>
              <Button variant="outline" className="rounded-xl">
                <Download className="w-4 h-4 mr-2" /> Baixar PDF
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </motion.main>
    </div>
  );
}
