import { queryClient } from "./queryClient";

const API_BASE = "/api";

async function fetchAPI<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options.headers,
    },
    credentials: "include",
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: "Erro de rede" }));
    throw new Error(error.message || "Erro na requisição");
  }

  if (response.status === 204) {
    return {} as T;
  }

  return response.json();
}

// Auth
export const authAPI = {
  login: (data: { username: string; password: string }) =>
    fetchAPI<{ user: any }>("/auth/login", { method: "POST", body: JSON.stringify(data) }),
  
  register: (data: { username: string; password: string; name: string; email: string }) =>
    fetchAPI<{ user: any }>("/auth/register", { method: "POST", body: JSON.stringify(data) }),
  
  logout: () => fetchAPI<void>("/auth/logout", { method: "POST" }),
  
  me: () => fetchAPI<{ user: any }>("/auth/me"),
  
  updateProfile: (data: any) =>
    fetchAPI<{ user: any }>("/auth/profile", { method: "PATCH", body: JSON.stringify(data) }),
  
  changePassword: (data: { currentPassword: string; newPassword: string }) =>
    fetchAPI<{ message: string }>("/auth/change-password", { method: "POST", body: JSON.stringify(data) }),
};

// Dashboard
export const dashboardAPI = {
  getStats: () => fetchAPI<any>("/dashboard"),
};

// Clients
export const clientsAPI = {
  getAll: () => fetchAPI<any[]>("/clients"),
  get: (id: string) => fetchAPI<any>(`/clients/${id}`),
  create: (data: any) => fetchAPI<any>("/clients", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => fetchAPI<any>(`/clients/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (id: string) => fetchAPI<void>(`/clients/${id}`, { method: "DELETE" }),
};

// Projects
export const projectsAPI = {
  getAll: () => fetchAPI<any[]>("/projects"),
  get: (id: string) => fetchAPI<any>(`/projects/${id}`),
  create: (data: any) => fetchAPI<any>("/projects", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => fetchAPI<any>(`/projects/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (id: string) => fetchAPI<void>(`/projects/${id}`, { method: "DELETE" }),
};

// Tasks
export const tasksAPI = {
  getAll: () => fetchAPI<any[]>("/tasks"),
  get: (id: string) => fetchAPI<any>(`/tasks/${id}`),
  create: (data: any) => fetchAPI<any>("/tasks", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => fetchAPI<any>(`/tasks/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (id: string) => fetchAPI<void>(`/tasks/${id}`, { method: "DELETE" }),
  getComments: (taskId: string) => fetchAPI<any[]>(`/tasks/${taskId}/comments`),
  addComment: (taskId: string, data: any) => fetchAPI<any>(`/tasks/${taskId}/comments`, { method: "POST", body: JSON.stringify(data) }),
};

// Invoices
export const invoicesAPI = {
  getAll: () => fetchAPI<any[]>("/invoices"),
  get: (id: string) => fetchAPI<any>(`/invoices/${id}`),
  create: (data: any) => fetchAPI<any>("/invoices", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => fetchAPI<any>(`/invoices/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (id: string) => fetchAPI<void>(`/invoices/${id}`, { method: "DELETE" }),
};

// Expenses
export const expensesAPI = {
  getAll: () => fetchAPI<any[]>("/expenses"),
  get: (id: string) => fetchAPI<any>(`/expenses/${id}`),
  create: (data: any) => fetchAPI<any>("/expenses", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => fetchAPI<any>(`/expenses/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (id: string) => fetchAPI<void>(`/expenses/${id}`, { method: "DELETE" }),
};

// Proposals
export const proposalsAPI = {
  getAll: () => fetchAPI<any[]>("/proposals"),
  get: (id: string) => fetchAPI<any>(`/proposals/${id}`),
  getByShareToken: (token: string) => fetchAPI<any>(`/proposals/share/${token}`),
  create: (data: any) => fetchAPI<any>("/proposals", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => fetchAPI<any>(`/proposals/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (id: string) => fetchAPI<void>(`/proposals/${id}`, { method: "DELETE" }),
};

// Investments
export const investmentsAPI = {
  getAll: () => fetchAPI<any[]>("/investments"),
  get: (id: string) => fetchAPI<any>(`/investments/${id}`),
  create: (data: any) => fetchAPI<any>("/investments", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => fetchAPI<any>(`/investments/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (id: string) => fetchAPI<void>(`/investments/${id}`, { method: "DELETE" }),
};

// Goals
export const goalsAPI = {
  getAll: () => fetchAPI<any[]>("/goals"),
  get: (id: string) => fetchAPI<any>(`/goals/${id}`),
  create: (data: any) => fetchAPI<any>("/goals", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => fetchAPI<any>(`/goals/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (id: string) => fetchAPI<void>(`/goals/${id}`, { method: "DELETE" }),
};

// Notifications
export const notificationsAPI = {
  getAll: () => fetchAPI<any[]>("/notifications"),
  create: (data: any) => fetchAPI<any>("/notifications", { method: "POST", body: JSON.stringify(data) }),
  markRead: (id: string) => fetchAPI<void>(`/notifications/${id}/read`, { method: "PATCH" }),
  markAllRead: () => fetchAPI<void>("/notifications/read-all", { method: "POST" }),
};

// Templates
export const templatesAPI = {
  getAll: () => fetchAPI<any[]>("/templates"),
  get: (id: string) => fetchAPI<any>(`/templates/${id}`),
  create: (data: any) => fetchAPI<any>("/templates", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => fetchAPI<any>(`/templates/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (id: string) => fetchAPI<void>(`/templates/${id}`, { method: "DELETE" }),
};

// Calendar
export const calendarAPI = {
  getAll: () => fetchAPI<any[]>("/calendar"),
  get: (id: string) => fetchAPI<any>(`/calendar/${id}`),
  create: (data: any) => fetchAPI<any>("/calendar", { method: "POST", body: JSON.stringify(data) }),
  update: (id: string, data: any) => fetchAPI<any>(`/calendar/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  delete: (id: string) => fetchAPI<void>(`/calendar/${id}`, { method: "DELETE" }),
};

// Chat
export const chatAPI = {
  getMessages: (clientId?: string) => fetchAPI<any[]>(`/chat${clientId ? `?clientId=${clientId}` : ""}`),
  sendMessage: (data: any) => fetchAPI<any>("/chat", { method: "POST", body: JSON.stringify(data) }),
};

// Attachments
export const attachmentsAPI = {
  getAll: (entityType: string, entityId: string) => fetchAPI<any[]>(`/attachments/${entityType}/${entityId}`),
  create: (data: any) => fetchAPI<any>("/attachments", { method: "POST", body: JSON.stringify(data) }),
  delete: (id: string) => fetchAPI<void>(`/attachments/${id}`, { method: "DELETE" }),
};
