# Lopes Control - CRM for Freelancers

## Overview

Lopes Control is a comprehensive CRM (Customer Relationship Management) application designed specifically for freelance designers and creative professionals. The platform provides end-to-end management of clients, projects, tasks, finances, proposals, investments, and goals.

The application is built as a full-stack TypeScript project with a React frontend and Express backend, following a monorepo structure with shared code between client and server.

**Target User:** Solo freelance designers who need to manage their entire business workflow in one place.

**Core Features:**
- Client management with revenue tracking
- Project lifecycle management with progress tracking
- Task management with drag-and-drop Kanban boards
- Financial tracking (invoices, expenses, cash flow)
- Proposal creation and management with shareable client portal
- Personal investment portfolio tracking
- Goal setting and progress monitoring
- Real-time notifications via WebSocket
- Calendar integration
- Template library for documents
- Theme switching with persistence (dark/light/system)

## User Preferences

- Preferred communication style: Simple, everyday language
- Preferred language: Portuguese (Brazil)

## Recent Changes (December 2025)

### Security Improvements (NEW)
- Enhanced login with account lockout after 5 failed attempts (15 min lock)
- Rate limiting on all sensitive routes (login, register, API)
- CSRF protection with SameSite cookies
- XSS sanitization on all inputs
- Helmet security headers (CSP, X-Frame-Options, etc.)
- Audit logging for login/logout and critical actions
- Security event logging for failed logins and suspicious activity
- RBAC (Role-Based Access Control) with admin/user/viewer roles
- JWT with short expiry + refresh tokens
- bcrypt password hashing
- Session cookies with httpOnly and secure flags

### Notification System (NEW)
- Created centralized NotificationService (server/notification-service.ts)
- 17+ notification types with Portuguese templates
- Automatic notifications for:
  - Creation: clients, projects, tasks, invoices, expenses, proposals, goals, calendar events
  - Updates: task completed, invoice paid, goal completed, proposal accepted
- Real-time delivery via WebSocket

### Settings Page (NEW - Full Functionality)
- **Profile Tab**: Name, email, phone, company - all saved to database
- **Appearance Tab**: 
  - Theme switching (Dark/Light/System) with persistence
  - Accent color selection (6 colors) saved to database
- **Notifications Tab**:
  - Email, Push, SMS preferences saved to database
  - "Save Preferences" button for notification settings
  - Notification history with unread indicator
- **Security Tab**:
  - Password change with current password validation
  - 2FA toggle (enable/disable) saved to database
  - Danger zone with account deletion option

### Bug Fixes & Improvements
- Auth.tsx: Added autocomplete attributes to all form inputs
- Goals.tsx: Added safeProgress() to prevent division by zero
- vite.config.ts: Configured HMR clientPort for Replit environment
- Fixed AnimatePresence issues in Auth.tsx
- Fixed DialogDescription warnings in Calendar and Templates

### API & Backend
- WebSocket server for real-time notifications (server/websocket.ts)
- NotificationContext for global client-side notification state
- All pages migrated from mock data to real API hooks
- Theme system persists via localStorage

## System Architecture

### Frontend Architecture
- **Framework:** React 18 with TypeScript
- **Routing:** Wouter (lightweight React router)
- **State Management:** TanStack React Query for server state
- **UI Components:** shadcn/ui component library built on Radix UI primitives
- **Styling:** Tailwind CSS v4 with CSS variables for theming
- **Animations:** Framer Motion for page transitions and micro-interactions
- **Charts:** Recharts for data visualization
- **Drag & Drop:** @dnd-kit for sortable task lists
- **Build Tool:** Vite
- **Real-time:** WebSocket connection for live notifications

### Backend Architecture
- **Runtime:** Node.js with Express
- **Language:** TypeScript compiled with tsx
- **API Pattern:** RESTful API with `/api` prefix
- **Database:** PostgreSQL with Drizzle ORM
- **Storage:** DatabaseStorage class with full CRUD operations
- **Authentication:** Session-based with bcrypt password hashing
- **Real-time:** WebSocket server for push notifications
- **Notifications:** Centralized NotificationService with automatic event triggers

### Design Patterns
- **Monorepo Structure:** Shared types and schemas between frontend and backend via `@shared` alias
- **Component Composition:** Layout wrapper pattern with sidebar navigation
- **Theme System:** Dark/light/system mode with CSS custom properties, persisted in localStorage
- **Context Providers:** AuthContext for auth state, NotificationContext for real-time notifications
- **Notification Architecture:** Event-driven with templates for 17+ event types

### Directory Structure
```
├── client/           # React frontend
│   ├── src/
│   │   ├── components/  # UI components (layout, ui library)
│   │   ├── contexts/    # React contexts (Auth, Notifications)
│   │   ├── pages/       # Route page components
│   │   ├── hooks/       # Custom React hooks (use-api, use-websocket)
│   │   └── lib/         # Utilities and query client
├── server/           # Express backend
│   ├── index.ts      # Server entry point
│   ├── routes.ts     # API route definitions
│   ├── storage.ts    # Database storage implementation
│   ├── websocket.ts  # WebSocket server for notifications
│   ├── notification-service.ts  # Centralized notification logic
│   └── db.ts         # Drizzle database connection
├── shared/           # Shared code between client/server
│   └── schema.ts     # Drizzle ORM schema and Zod validation
└── migrations/       # Database migrations (Drizzle)
```

## Notification Types

| Event Type | Trigger | Template (PT-BR) |
|------------|---------|------------------|
| project_created | POST /api/projects | "Projeto X foi criado com sucesso" |
| task_created | POST /api/tasks | "Tarefa X foi criada" |
| task_completed | PATCH /api/tasks (status=done) | "Tarefa X foi concluída" |
| invoice_created | POST /api/invoices | "Fatura de R$ X foi criada" |
| invoice_paid | PATCH /api/invoices (status=paid) | "Pagamento de R$ X foi recebido!" |
| expense_created | POST /api/expenses | "Despesa X de R$ X foi registrada" |
| proposal_created | POST /api/proposals | "Proposta X foi criada" |
| proposal_accepted | PATCH /api/proposals (status=accepted) | "Proposta X foi aceita!" |
| goal_created | POST /api/goals | "Meta X foi criada" |
| goal_completed | PATCH /api/goals (progress>=100%) | "Parabéns! Você atingiu a meta X!" |
| client_created | POST /api/clients | "Cliente X foi adicionado" |
| calendar_event_created | POST /api/calendar | "Evento X foi agendado" |

## External Dependencies

### Database
- **ORM:** Drizzle ORM configured for PostgreSQL
- **Schema Location:** `shared/schema.ts`
- **Migrations:** Managed via `drizzle-kit push`
- **Connection:** Requires `DATABASE_URL` environment variable

### UI Component Libraries
- **Radix UI:** Complete primitive library for accessible components
- **shadcn/ui:** Pre-styled component system (new-york style variant)
- **Lucide React:** Icon library

### Third-Party Services
- **WebSocket:** Native ws library for real-time communication
- **Session Management:** MemoryStore for sessions (production should use connect-pg-simple)
- **Email:** Nodemailer configured in build dependencies

### Development Tools
- **Replit Plugins:** Cartographer, dev banner, runtime error overlay
- **Meta Images:** Custom Vite plugin for OpenGraph image handling

### Branding Configuration
- **Primary Color:** #FF00AA (magenta/pink)
- **Color Scheme:** Dark mode default, supports light and system
- **Fonts:** Rajdhani (headings), Inter (body)
- **Language:** Portuguese (Brazil)
