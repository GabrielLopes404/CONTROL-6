import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { Request, Response, NextFunction, Express } from "express";
import xss from "xss";
import { db } from "./db";
import { securityEvents, auditLogs } from "@shared/schema";

const MAX_LOGIN_ATTEMPTS = 5;
const LOCK_TIME = 15 * 60 * 1000; // 15 minutes

export const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // 10 login attempts per window
  message: { message: "Muitas tentativas de login. Tente novamente em 15 minutos." },
  standardHeaders: true,
  legacyHeaders: false,
});

export const apiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute
  message: { message: "Muitas requisições. Tente novamente em alguns segundos." },
  standardHeaders: true,
  legacyHeaders: false,
});

export const strictLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 10, // 10 requests per minute for sensitive operations
  message: { message: "Limite de requisições atingido. Aguarde antes de tentar novamente." },
  standardHeaders: true,
  legacyHeaders: false,
});

export function sanitizeInput(input: any): any {
  if (typeof input === "string") {
    return xss(input.trim());
  }
  if (Array.isArray(input)) {
    return input.map(sanitizeInput);
  }
  if (typeof input === "object" && input !== null) {
    const sanitized: Record<string, any> = {};
    for (const [key, value] of Object.entries(input)) {
      sanitized[sanitizeInput(key)] = sanitizeInput(value);
    }
    return sanitized;
  }
  return input;
}

export function sanitizeMiddleware(req: Request, res: Response, next: NextFunction) {
  if (req.body) {
    req.body = sanitizeInput(req.body);
  }
  if (req.query) {
    req.query = sanitizeInput(req.query);
  }
  if (req.params) {
    req.params = sanitizeInput(req.params);
  }
  next();
}

export function getClientIp(req: Request): string {
  return (
    (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() ||
    req.socket.remoteAddress ||
    "unknown"
  );
}

export async function logSecurityEvent(
  type: string,
  req: Request,
  userId?: string,
  details?: any
) {
  try {
    await db.insert(securityEvents).values({
      type,
      userId: userId || null,
      ipAddress: getClientIp(req),
      userAgent: req.headers["user-agent"] || null,
      details: details || null,
    });
  } catch (error) {
    console.error("Failed to log security event:", error);
  }
}

export async function logAuditAction(
  action: string,
  req: Request,
  entityType?: string,
  entityId?: string,
  oldData?: any,
  newData?: any
) {
  try {
    const userId = (req.session as any)?.userId || null;
    await db.insert(auditLogs).values({
      userId,
      action,
      entityType: entityType || null,
      entityId: entityId || null,
      oldData: oldData ? JSON.parse(JSON.stringify(oldData, (key, value) => {
        if (key === "password" || key === "token") return "[REDACTED]";
        return value;
      })) : null,
      newData: newData ? JSON.parse(JSON.stringify(newData, (key, value) => {
        if (key === "password" || key === "token") return "[REDACTED]";
        return value;
      })) : null,
      ipAddress: getClientIp(req),
      userAgent: req.headers["user-agent"] || null,
    });
  } catch (error) {
    console.error("Failed to log audit action:", error);
  }
}

export function setupSecurityMiddleware(app: Express) {
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
          fontSrc: ["'self'", "https://fonts.gstatic.com"],
          imgSrc: ["'self'", "data:", "https:", "blob:"],
          scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
          connectSrc: ["'self'", "wss:", "ws:"],
        },
      },
      crossOriginEmbedderPolicy: false,
      crossOriginResourcePolicy: { policy: "cross-origin" },
    })
  );

  app.disable("x-powered-by");

  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader(
      "Permissions-Policy",
      "geolocation=(), microphone=(), camera=()"
    );
    next();
  });

  app.use("/api", apiLimiter);
  app.use("/api/auth/login", loginLimiter);
  app.use("/api/auth/register", loginLimiter);

  app.use(sanitizeMiddleware);
}

export { MAX_LOGIN_ATTEMPTS, LOCK_TIME };
